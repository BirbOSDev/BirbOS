# BirbOS
A basic Batch OS developed by Dukemz, xandrei and Ad2017.
Current version: (7.2.4)

*note that this is not an actual OS and it's just a fun batch program.*
